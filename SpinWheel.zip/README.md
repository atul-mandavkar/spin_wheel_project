# spin_wheel_project
1) Website should get open after scanning QR code
2) After landing o  user's page first advertisement get shown which is not skippable
3) After a survey form will appear
4) After that a game of spin wheel game, in that game if user win then redeem button will shown else "better luck next time" msg shown
5) At the end a Thank you msg will shown
