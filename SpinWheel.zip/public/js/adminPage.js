// const API_URL = "http://localhost:4000/user/";

// const loginBtn = document.getElementById("loginBtn");
// const logoutBtn = document.getElementById("logoutBtn");
// const userTable = document.getElementById("userTable");

// checkLoginStatus();

// loginBtn.addEventListener("click", handleLogin);
// logoutBtn.addEventListener("click", handleLogout);

// function checkLoginStatus() {
//   const isLoggedIn = !!localStorage.getItem("adminLoggedIn");
//   if (isLoggedIn) {
//     loginBtn.style.display = "none";
//     logoutBtn.style.display = "block";
//     userTable.style.display = "block";
//     fetchUserData();
//   } else {
//     loginBtn.style.display = "block";
//     logoutBtn.style.display = "none";
//     userTable.style.display = "none";
//   }
// }

// function handleLogin() {
//   localStorage.setItem("adminLoggedIn", true);
//   checkLoginStatus();
// }

// function handleLogout() {
//   localStorage.removeItem("adminLoggedIn");
//   checkLoginStatus();
// }

// function fetchUserData() {
//   fetch(API_URL)
//     .then(response => {
//       if (!response.ok) {
//         throw new Error("Failed to fetch user data.");
//       }
//       return response.json();
//     })
//     .then(data => {
//       populateTable(data);
//     })
//     .catch(error => {
//       console.error('Error fetching user data:', error);
//     });
// }

// function populateTable(userData) {
//     const tbody = document.querySelector("#userTable tbody");
//     tbody.innerHTML = ""; // Clear existing data
  
//     if (!userData || !Array.isArray(userData.allUser)) {
//       console.error("Invalid user data format:", userData);
//       return;
//     }
  
//     userData.allUser.forEach(user => {
//       const tr = `
//         <tr>
//           <td>${user.userName}</td>
//           <td>${user.userEmail}</td>
//           <td>${user.userReward}</td>
//           <td>${formatUserLocation(user.userLocation)}</td>
//           <!-- Add more table data for other user data if needed -->
//         </tr>
//       `;
  
//       tbody.innerHTML += tr;
//     });
//   }
  
  

// function formatUserLocation(location) {
//   if (location && location.length === 2) {
//     const [latitude, longitude] = location;
//     return `Latitude: ${latitude}, Longitude: ${longitude}`;
//   } else {
//     return "Location Not Available";
//   }
// }



// const API_URL = "http://localhost:4000/user/";
// const userTable = document.getElementById("userTable");

// fetchUserData();

// function fetchUserData() {
//   fetch(API_URL)
//     .then(response => {
//       if (!response.ok) {
//         throw new Error("Failed to fetch user data.");
//       }
//       return response.json();
//     })
//     .then(data => {
//       populateTable(data);
//     })
//     .catch(error => {
//       console.error('Error fetching user data:', error);
//     });
// }

// function populateTable(userData) {
//   const tbody = document.querySelector("#userTable tbody");
//   tbody.innerHTML = ""; // Clear existing data

//   if (!userData || !Array.isArray(userData.allUser)) {
//     console.error("Invalid user data format:", userData);
//     return;
//   }

//   userData.allUser.forEach(user => {
//     const tr = `
//       <tr>
//         <td>${user.userName}</td>
//         <td>${user.userEmail}</td>
//         <td>${user.userReward}</td>
//         <td class="location" data-lat="${user.userLocation[0]}" data-lng="${user.userLocation[1]}">${formatUserLocation(user.userLocation)}</td>
//       </tr>
//     `;

//     tbody.innerHTML += tr;
//   });

//   // Add event listener to handle click on location
//   const locations = document.querySelectorAll(".location");
//   locations.forEach(location => {
//     location.addEventListener("click", handleLocationClick);
//   });
// }

// function formatUserLocation(location) {
//   if (location && location.length === 2) {
//     const [latitude, longitude] = location;
//     return `Latitude: ${latitude}, Longitude: ${longitude}`;
//   } else {
//     return "Location Not Available";
//   }
// }

// function handleLocationClick(event) {
//   const latitude = event.target.getAttribute("data-lat");
//   const longitude = event.target.getAttribute("data-lng");
//   const mapUrl = `https://www.google.com/maps?q=${latitude},${longitude}`;
//   window.open(mapUrl, "_blank");
// }


const API_URL = "http://localhost:4000/user/";
const userTable = document.getElementById("userTable");

fetchUserData();

function fetchUserData() {
  fetch(API_URL)
    .then(response => {
      if (!response.ok) {
        throw new Error("Failed to fetch user data.");
      }
      return response.json();
    })
    .then(data => {
      populateTable(data);
    })
    .catch(error => {
      console.error('Error fetching user data:', error);
    });
}

function populateTable(userData) {
  const tbody = document.querySelector("#userTable tbody");
  tbody.innerHTML = ""; // Clear existing data

  if (!userData || !Array.isArray(userData.allUser)) {
    console.error("Invalid user data format:", userData);
    return;
  }

  userData.allUser.forEach(user => {
    const tr = `
      <tr>
        <td>${user.userName}</td>
        <td>${user.userEmail}</td>
        <td>${user.userReward}</td>
        <td class="location" data-lat="${user.userLocation[0]}" data-lng="${user.userLocation[1]}">${formatUserLocation(user.userLocation)}</td>
      </tr>
    `;

    tbody.innerHTML += tr;
  });

  // Add event listener to handle click on location
  const locations = document.querySelectorAll(".location");
  locations.forEach(location => {
    location.addEventListener("click", handleLocationClick);
  });
}

function formatUserLocation(location) {
  if (location && location.length === 2) {
    const [latitude, longitude] = location;
    return `Latitude: ${latitude}, Longitude: ${longitude}`;
  } else {
    return "Location Not Available";
  }
}

function handleLocationClick(event) {
  const latitude = event.target.getAttribute("data-lat");
  const longitude = event.target.getAttribute("data-lng");
  const mapUrl = `https://www.google.com/maps?q=${latitude},${longitude}`;
  window.open(mapUrl, "_blank");
}

// Get user location using Geolocation API
navigator.geolocation.getCurrentPosition(
  position => {
    const { latitude, longitude } = position.coords;
    // Update userLocation in the table with the user's actual location
    const locations = document.querySelectorAll(".location");
    locations.forEach(location => {
      location.textContent = `Latitude: ${latitude}, Longitude: ${longitude}`;
      location.setAttribute("data-lat", latitude);
      location.setAttribute("data-lng", longitude);
    });
  },
  error => {
    console.error("Error getting user location:", error);
  }
);