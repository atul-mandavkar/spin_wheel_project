const mongoose = require("mongoose");
const userSchema = new mongoose.Schema({
    userName:{
        type:String,
        required:[true,"user name is required"]
    },
    userEmail:{
        type:String,
        required:[true,"user email is required"]
    },
    userLocation:{
        type:[Number],
        required: false 
    },
    userAnswer:{
        type:[String],
        required:[true,"user answer is required"]
    },  
    userReward:{
        type:String,
        required:[true,"user reward is required"]
    }
},
{timestamps:true}
)

const userModel = mongoose.model("user",userSchema);
module.exports = userModel;