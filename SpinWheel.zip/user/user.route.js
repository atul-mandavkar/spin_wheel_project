const express = require("express");
const { getUser, addUser } = require("./user.controller");
const userRouter = express.Router();

userRouter.route("/")
    .get(getUser)
    .post(addUser)

module.exports = userRouter;