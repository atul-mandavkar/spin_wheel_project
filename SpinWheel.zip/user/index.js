import express from 'express';
import cors from "cors";
import userRouter from './user.route';
const mongoose = require("mongoose");
const bodyParser = require("body-parser");

const Port = 4000;

const app = express();

app.use(cors());
var corsOptions = {
  origin: ["http://localhost:3000", "http://localhost:3001"],
  optionsSuccessStatus: 200, // some legacy browsers (IE11, various SmartTVs) choke on 204
};
app.use(cors(corsOptions));

app.use(express.static(__dirname));
app.use(bodyParser.json());

app.use("/user" ,userRouter)
app.get('/', function (req, res) {
 res.send('Hello World!');
});

mongoose
  .connect("mongodb://localhost:27017/SpinWheel")
  .then(() => {
    console.log("mongodb started");
  })
  .catch(() => {
    console.log("mongodb connection error");
});

app.listen(Port, function () {
  console.log(`Example app listening on port ${Port}!`);
});
