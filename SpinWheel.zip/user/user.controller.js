const userModel  = require("./user.model")

exports.getUser = async (req,res)=>{
    try {
        const allUser = await userModel.find();
        res.status(200).json({
            status:"success",
            allUser
        })
    } catch (error) {
        res.status(400).json({
            status:"failed",
            message:error.message
        })
    }
}

exports.addUser = async (req,res)=>{
    try {
        const addUser = await userModel.create(req.body);
        res.status(200).json({
            status:"success",
            addUser
        })
    } catch (error) {
        res.status(400).json({
            status:"failed",
            message:error.message
        })
    }
}